/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Dog, Activity } from './types';
import Dashboard from './components/Dashboard';
import DogsList from './components/DogsList';
import ActivityLog from './components/ActivityLog';
import PawVisor from './components/PawVisor';
import { Layout, Dog as DogIcon, Activity as ActivityIcon, Compass, History } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const STORAGE_KEY_DOGS = 'dailyfitdog_dogs';
const STORAGE_KEY_ACTIVITIES = 'dailyfitdog_activities';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'dogs' | 'log' | 'ai'>('dashboard');
  const [dogs, setDogs] = useState<Dog[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [selectedDogId, setSelectedDogId] = useState<string | null>(null);

  useEffect(() => {
    const savedDogs = localStorage.getItem(STORAGE_KEY_DOGS);
    const savedActivities = localStorage.getItem(STORAGE_KEY_ACTIVITIES);
    
    if (savedDogs) setDogs(JSON.parse(savedDogs));
    if (savedActivities) setActivities(JSON.parse(savedActivities));
    
    // Default selection if dogs exist
    if (savedDogs) {
      const parsed = JSON.parse(savedDogs);
      if (parsed.length > 0) setSelectedDogId(parsed[0].id);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_DOGS, JSON.stringify(dogs));
  }, [dogs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ACTIVITIES, JSON.stringify(activities));
  }, [activities]);

  const addDog = (dog: Dog) => {
    setDogs([...dogs, dog]);
    if (!selectedDogId) setSelectedDogId(dog.id);
  };

  const updateDog = (updatedDog: Dog) => {
    setDogs(dogs.map(d => d.id === updatedDog.id ? updatedDog : d));
  };

  const logActivity = (activity: Activity) => {
    setActivities([activity, ...activities]);
  };

  const selectedDog = dogs.find(d => d.id === selectedDogId) || null;

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-cream-100 overflow-hidden">
      {/* Sidebar/Nav */}
      <nav className="fixed bottom-0 left-0 w-full md:relative md:w-20 md:h-screen bg-sage-800 text-cream-100 flex md:flex-col justify-around md:justify-center items-center py-4 z-50">
        <NavItem 
          active={activeTab === 'dashboard'} 
          onClick={() => setActiveTab('dashboard')} 
          icon={<Layout size={24} />} 
          label="Home"
        />
        <NavItem 
          active={activeTab === 'dogs'} 
          onClick={() => setActiveTab('dogs')} 
          icon={<DogIcon size={24} />} 
          label="Dogs"
        />
        <NavItem 
          active={activeTab === 'log'} 
          onClick={() => setActiveTab('log')} 
          icon={<History size={24} />} 
          label="Log"
        />
        <NavItem 
          active={activeTab === 'ai'} 
          onClick={() => setActiveTab('ai')} 
          icon={<Compass size={24} />} 
          label="Explore"
        />
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 h-full overflow-y-auto pb-24 md:pb-0 relative">
        <header className="p-6 md:p-10 flex justify-between items-center bg-cream-100/80 sticky top-0 z-40 backdrop-blur-sm">
          <div>
            <h1 className="text-3xl md:text-4xl serif font-bold text-sage-900">
              {activeTab === 'dashboard' && 'Daily Progress'}
              {activeTab === 'dogs' && 'My Pack'}
              {activeTab === 'log' && 'Activity Log'}
              {activeTab === 'ai' && 'Paw-visor AI'}
            </h1>
            <p className="text-sage-600 font-medium">
              {selectedDog ? `Focusing on ${selectedDog.name}` : 'Welcome to DailyFitDog'}
            </p>
          </div>

          {dogs.length > 1 && (
            <select 
              value={selectedDogId || ''} 
              onChange={(e) => setSelectedDogId(e.target.value)}
              className="bg-white border border-sage-200 rounded-full px-4 py-2 text-sage-800 outline-none focus:ring-2 focus:ring-sage-500 transition-all font-medium"
            >
              {dogs.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          )}
        </header>

        <section className="px-6 md:px-10 pb-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {activeTab === 'dashboard' && (
                <Dashboard 
                  dog={selectedDog} 
                  activities={activities.filter(a => a.dogId === selectedDogId)} 
                  onLogActivity={logActivity}
                />
              )}
              {activeTab === 'dogs' && (
                <DogsList 
                  dogs={dogs} 
                  onAddDog={addDog} 
                  onUpdateDog={updateDog}
                />
              )}
              {activeTab === 'log' && (
                <ActivityLog 
                  activities={activities.filter(a => a.dogId === selectedDogId)} 
                />
              )}
              {activeTab === 'ai' && (
                <PawVisor dog={selectedDog} />
              )}
            </motion.div>
          </AnimatePresence>
        </section>
      </main>
    </div>
  );
}

function NavItem({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={`group flex flex-col items-center gap-1 transition-all duration-300 relative ${active ? 'text-cream-500' : 'text-sage-300 hover:text-cream-100'}`}
    >
      <div className={`p-3 rounded-2xl transition-all duration-300 ${active ? 'bg-sage-700 shadow-lg scale-110' : 'bg-transparent'}`}>
        {icon}
      </div>
      <span className="text-[10px] uppercase tracking-widest font-bold opacity-0 group-hover:opacity-100 md:group-hover:opacity-100 transition-opacity whitespace-nowrap">
        {label}
      </span>
      {active && (
        <motion.div 
          layoutId="activeNav"
          className="absolute -right-1 top-0 w-1 h-8 bg-cream-500 rounded-full hidden md:block" 
        />
      )}
    </button>
  );
}
