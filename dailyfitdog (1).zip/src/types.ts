/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Dog {
  id: string;
  name: string;
  breed: string;
  age: number;
  weight: number;
  activityLevel: 'low' | 'moderate' | 'high';
  goals: {
    walkMinutes: number;
    playMinutes: number;
    trainingMinutes: number;
  };
}

export interface Activity {
  id: string;
  dogId: string;
  type: 'walk' | 'play' | 'training' | 'other';
  duration: number; // in minutes
  timestamp: string;
  notes?: string;
}

export interface DailyLog {
  date: string;
  dogId: string;
  activities: Activity[];
  weight?: number;
  waterIntake: number; // 0-10 scale or oz
}
