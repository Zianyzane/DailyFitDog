/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Dog, Activity } from '../types';
import { Plus, Footprints, Flame, Timer, Trophy } from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
  PieChart, Pie
} from 'recharts';
import { motion } from 'motion/react';

interface DashboardProps {
  dog: Dog | null;
  activities: Activity[];
  onLogActivity: (activity: Activity) => void;
}

export default function Dashboard({ dog, activities, onLogActivity }: DashboardProps) {
  const [isLogging, setIsLogging] = useState(false);
  const [activityType, setActivityType] = useState<Activity['type']>('walk');
  const [duration, setDuration] = useState('30');

  if (!dog) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center">
        <div className="bg-sage-100 p-8 rounded-full mb-6">
          <Footprints size={48} className="text-sage-400" />
        </div>
        <h2 className="text-2xl font-bold text-sage-900 serif mb-2">No Dog Selected</h2>
        <p className="text-sage-600 max-w-sm">
          Add your furry friend in the **Dogs** tab to start tracking their fitness and wellness!
        </p>
      </div>
    );
  }

  // Calculate daily progress
  const today = new Date().toISOString().split('T')[0];
  const todaysActivities = activities.filter(a => a.timestamp.startsWith(today));
  
  const actualWalks = todaysActivities.filter(a => a.type === 'walk').reduce((acc, curr) => acc + curr.duration, 0);
  const actualPlay = todaysActivities.filter(a => a.type === 'play').reduce((acc, curr) => acc + curr.duration, 0);
  const actualTraining = todaysActivities.filter(a => a.type === 'training').reduce((acc, curr) => acc + curr.duration, 0);

  const stats = [
    { label: 'Walk', current: actualWalks, goal: dog.goals.walkMinutes, color: '#64816e' },
    { label: 'Play', current: actualPlay, goal: dog.goals.playMinutes, color: '#ddb871' },
    { label: 'Train', current: actualTraining, goal: dog.goals.trainingMinutes, color: '#e9d19e' },
  ];

  const handleLogSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const activity: Activity = {
      id: crypto.randomUUID(),
      dogId: dog.id,
      type: activityType,
      duration: parseInt(duration),
      timestamp: new Date().toISOString(),
    };
    onLogActivity(activity);
    setIsLogging(false);
  };

  return (
    <div className="space-y-8">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, i) => {
          const progress = Math.min((stat.current / stat.goal) * 100, 100);
          return (
            <motion.div 
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              className="glass-card p-6 flex flex-col items-center justify-center text-center relative overflow-hidden"
            >
              <div 
                className="absolute bottom-0 left-0 h-1 bg-opacity-50 transition-all duration-1000"
                style={{ width: `${progress}%`, backgroundColor: stat.color }}
              />
              <span className="text-sm font-bold uppercase tracking-widest text-sage-400 mb-2">{stat.label}</span>
              <div className="text-4xl font-black text-sage-900 mb-1">
                {stat.current}<span className="text-lg font-medium text-sage-400">/{stat.goal}m</span>
              </div>
              <div className="text-xs font-bold text-sage-600">
                {progress >= 100 ? 'Goal Reached! 🏆' : `${Math.round(progress)}% of daily goal`}
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Chart */}
        <div className="lg:col-span-2 glass-card p-8">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold serif text-sage-900">Activity Distribution</h3>
            <div className="flex items-center gap-2 text-sage-500 font-medium text-sm">
              <Timer size={16} /> Last 7 Days
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E8EDE8" />
                <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: '#64816e', fontWeight: 600 }} />
                <YAxis hide />
                <Tooltip 
                  cursor={{ fill: 'rgba(100, 129, 110, 0.05)' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="current" radius={[10, 10, 0, 0]} barSize={60}>
                  {stats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-6">
          <div className="glass-card p-6 bg-sage-500 text-white border-none">
            {!isLogging ? (
              <div className="flex flex-col items-center text-center">
                <div className="bg-white/20 p-4 rounded-full mb-4">
                  <Flame size={32} />
                </div>
                <h4 className="text-xl font-bold serif mb-2">Record Activity</h4>
                <p className="text-sage-100 text-sm mb-6">Finished a walk or playtime? Track it now to reach your daily goal!</p>
                <button 
                  onClick={() => setIsLogging(true)}
                  className="w-full bg-white text-sage-600 py-3 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-cream-100 transition-colors shadow-lg"
                >
                  <Plus size={20} /> Log Activity
                </button>
              </div>
            ) : (
              <form onSubmit={handleLogSubmit} className="space-y-4">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-lg font-bold">New Entry</h4>
                  <button type="button" onClick={() => setIsLogging(false)} className="text-xs font-bold uppercase tracking-widest text-sage-200">Cancel</button>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-sage-200 mb-1">Activity Type</label>
                  <div className="grid grid-cols-3 gap-2">
                    {['walk', 'play', 'training'].map(type => (
                      <button 
                        key={type}
                        type="button"
                        onClick={() => setActivityType(type as any)}
                        className={`py-2 rounded-xl text-xs font-bold transition-all ${activityType === type ? 'bg-white text-sage-600' : 'bg-white/10 text-white border border-white/20 hover:bg-white/20'}`}
                      >
                        {type.charAt(0).toUpperCase() + type.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-sage-200 mb-1">Duration (min)</label>
                  <input 
                    type="number" 
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    className="w-full bg-white/20 border border-white/30 rounded-xl px-4 py-3 text-white outline-none focus:bg-white/30 transition-all font-bold"
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full bg-cream-400 text-sage-900 py-3 rounded-2xl font-black mt-2 shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all"
                >
                  Confirm Log
                </button>
              </form>
            )}
          </div>

          <div className="glass-card p-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-sage-100 p-3 rounded-2xl text-sage-500">
                <Trophy size={24} />
              </div>
              <div>
                <h5 className="font-bold text-sage-900">Current Streak</h5>
                <p className="text-xs text-sage-500 font-medium">Keep it up! 5 days in a row.</p>
              </div>
            </div>
            <div className="text-2xl font-black text-sage-500">5</div>
          </div>
        </div>
      </div>
    </div>
  );
}
