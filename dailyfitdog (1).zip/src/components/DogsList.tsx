/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Dog } from '../types';
import { Plus, Trash2, Edit2, Scale, Bone, Activity as ActivityIcon, ChevronRight, Timer } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface DogsListProps {
  dogs: Dog[];
  onAddDog: (dog: Dog) => void;
  onUpdateDog: (dog: Dog) => void;
}

export default function DogsList({ dogs, onAddDog, onUpdateDog }: DogsListProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    breed: '',
    age: '',
    weight: '',
    activityLevel: 'moderate' as Dog['activityLevel'],
    walkGoal: '30',
    playGoal: '20',
    trainGoal: '10'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newDog: Dog = {
      id: crypto.randomUUID(),
      name: formData.name,
      breed: formData.breed,
      age: parseInt(formData.age),
      weight: parseFloat(formData.weight),
      activityLevel: formData.activityLevel,
      goals: {
        walkMinutes: parseInt(formData.walkGoal),
        playMinutes: parseInt(formData.playGoal),
        trainingMinutes: parseInt(formData.trainGoal)
      }
    };
    onAddDog(newDog);
    setIsAdding(false);
    setFormData({ name: '', breed: '', age: '', weight: '', activityLevel: 'moderate', walkGoal: '30', playGoal: '20', trainGoal: '10' });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-sage-900 serif">Your Pack</h2>
        {!isAdding && (
          <button 
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-2 bg-sage-500 text-white px-5 py-2.5 rounded-full font-bold hover:bg-sage-600 transition-all shadow-md"
          >
            <Plus size={20} /> Add New Dog
          </button>
        )}
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <form onSubmit={handleSubmit} className="glass-card p-8 grid grid-cols-1 md:grid-cols-2 gap-6 bg-cream-50 border-sage-200">
              <div className="space-y-4">
                <h3 className="text-lg font-bold serif text-sage-700 border-b border-sage-100 pb-2 mb-4">Core Stats</h3>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-sage-400 mb-1">Name</label>
                  <input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-white border border-sage-200 rounded-xl px-4 py-2.5 focus:border-sage-500 outline-none transition-all shadow-sm" placeholder="Buddy" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-sage-400 mb-1">Breed</label>
                  <input required value={formData.breed} onChange={e => setFormData({...formData, breed: e.target.value})} className="w-full bg-white border border-sage-200 rounded-xl px-4 py-2.5 focus:border-sage-500 outline-none transition-all shadow-sm" placeholder="Golden Retriever" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-sage-400 mb-1">Age (Years)</label>
                    <input required type="number" value={formData.age} onChange={e => setFormData({...formData, age: e.target.value})} className="w-full bg-white border border-sage-200 rounded-xl px-4 py-2.5 focus:border-sage-500 outline-none transition-all shadow-sm" placeholder="3" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-sage-400 mb-1">Weight (kg)</label>
                    <input required type="number" step="0.1" value={formData.weight} onChange={e => setFormData({...formData, weight: e.target.value})} className="w-full bg-white border border-sage-200 rounded-xl px-4 py-2.5 focus:border-sage-500 outline-none transition-all shadow-sm" placeholder="25" />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-bold serif text-sage-700 border-b border-sage-100 pb-2 mb-4">Daily Goals (Minutes)</h3>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-sage-400 mb-1">Activity Level</label>
                  <select value={formData.activityLevel} onChange={e => setFormData({...formData, activityLevel: e.target.value as any})} className="w-full bg-white border border-sage-200 rounded-xl px-4 py-2.5 outline-none shadow-sm">
                    <option value="low">Low Energy</option>
                    <option value="moderate">Moderate Energy</option>
                    <option value="high">High Energy</option>
                  </select>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-sage-400 mb-1 text-center">Walk</label>
                    <input type="number" value={formData.walkGoal} onChange={e => setFormData({...formData, walkGoal: e.target.value})} className="w-full bg-white border border-sage-200 rounded-xl px-2 py-2.5 text-center font-bold outline-none" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-sage-400 mb-1 text-center">Play</label>
                    <input type="number" value={formData.playGoal} onChange={e => setFormData({...formData, playGoal: e.target.value})} className="w-full bg-white border border-sage-200 rounded-xl px-2 py-2.5 text-center font-bold outline-none" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-widest text-sage-400 mb-1 text-center">Train</label>
                    <input type="number" value={formData.trainGoal} onChange={e => setFormData({...formData, trainGoal: e.target.value})} className="w-full bg-white border border-sage-200 rounded-xl px-2 py-2.5 text-center font-bold outline-none" />
                  </div>
                </div>
                <div className="flex gap-4 pt-4">
                  <button type="button" onClick={() => setIsAdding(false)} className="flex-1 px-4 py-3 border border-sage-200 rounded-xl font-bold text-sage-600 hover:bg-sage-50 transition-all">Cancel</button>
                  <button type="submit" className="flex-1 px-4 py-3 bg-sage-500 text-white rounded-xl font-bold hover:bg-sage-600 transition-all shadow-md">Save Dog</button>
                </div>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {dogs.map((dog, idx) => (
          <motion.div 
            key={dog.id} 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="glass-card group overflow-hidden"
          >
            <div className="p-1 h-2 bg-sage-200 group-hover:bg-sage-500 transition-colors" />
            <div className="p-6">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-2xl font-bold serif text-sage-900">{dog.name}</h3>
                  <p className="text-sage-500 font-medium">{dog.breed} • {dog.age} Years</p>
                </div>
                <div className="bg-cream-200 p-3 rounded-full text-sage-600 group-hover:scale-110 transition-transform">
                  <Bone size={24} />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="p-3 bg-sage-50 rounded-2xl text-center">
                  <Scale size={18} className="mx-auto mb-1 text-sage-400" />
                  <div className="font-bold text-sage-800">{dog.weight}kg</div>
                  <div className="text-[10px] uppercase font-bold text-sage-400">Weight</div>
                </div>
                <div className="p-3 bg-sage-50 rounded-2xl text-center">
                  <ActivityIcon size={18} className="mx-auto mb-1 text-sage-400" />
                  <div className="font-bold text-sage-800 capitalize">{dog.activityLevel}</div>
                  <div className="text-[10px] uppercase font-bold text-sage-400">Energy</div>
                </div>
                <div className="p-3 bg-sage-50 rounded-2xl text-center">
                  <Timer size={18} className="mx-auto mb-1 text-sage-400" />
                  <div className="font-bold text-sage-800">{dog.goals.walkMinutes + dog.goals.playMinutes + dog.goals.trainingMinutes}m</div>
                  <div className="text-[10px] uppercase font-bold text-sage-400">Target</div>
                </div>
              </div>

              <div className="flex items-center justify-between text-sage-400 hover:text-sage-700 cursor-pointer transition-colors group/edit">
                <span className="text-sm font-bold uppercase tracking-widest">Configuration Profile</span>
                <ChevronRight size={18} className="group-hover/edit:translate-x-1 transition-transform" />
              </div>
            </div>
          </motion.div>
        ))}

        {dogs.length === 0 && !isAdding && (
          <div 
            onClick={() => setIsAdding(true)}
            className="border-2 border-dashed border-sage-200 rounded-3xl p-12 flex flex-col items-center justify-center text-sage-400 hover:text-sage-600 hover:border-sage-400 hover:bg-white/40 cursor-pointer transition-all"
          >
            <Plus size={48} className="mb-4" />
            <p className="font-bold serif text-xl">Register your first dog</p>
            <p className="text-sm">Click to begin the onboarding</p>
          </div>
        )}
      </div>
    </div>
  );
}
