/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Dog } from '../types';
import { Sparkles, MessageCircle, Send, User, ChevronRight, Wand2, ThermometerSun, Stethoscope, Footprints, Activity as ActivityIcon, Scale } from 'lucide-react';
import { getDogAdvice, generateDailyRoutine } from '../services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';

interface PawVisorProps {
  dog: Dog | null;
}

export default function PawVisor({ dog }: PawVisorProps) {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', content: string }[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [routine, setRoutine] = useState<any>(null);
  const [isGeneratingRoutine, setIsGeneratingRoutine] = useState(false);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !dog || isLoading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    const aiResponse = await getDogAdvice(dog, userMsg);
    setMessages(prev => [...prev, { role: 'ai', content: aiResponse || "Sorry, I couldn't get an answer." }]);
    setIsLoading(false);
  };

  const handleGenerateRoutine = async () => {
    if (!dog || isGeneratingRoutine) return;
    setIsGeneratingRoutine(true);
    const result = await generateDailyRoutine(dog);
    setRoutine(result);
    setIsGeneratingRoutine(false);
  };

  if (!dog) {
    return (
      <div className="flex flex-col items-center justify-center p-20 text-center text-sage-400">
        <Sparkles size={64} strokeWidth={1} className="mb-4 opacity-50" />
        <h3 className="text-xl font-bold serif mb-2">Paw-visor is Ready</h3>
        <p className="max-w-xs text-sm">Please select a dog to get personalized AI wellness advice.</p>
      </div>
    );
  }

  const suggestedQuestions = [
    { text: `Best exercises for ${dog.breed}s?`, icon: <ActivityIcon size={14} /> },
    { text: `Ideal weight for a ${dog.age}yo ${dog.breed}?`, icon: <Scale size={14} /> },
    { text: "Signs of over-exertion?", icon: <ThermometerSun size={14} /> },
    { text: "Low-impact indoor plays?", icon: <Stethoscope size={14} /> },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-[calc(100vh-200px)]">
      {/* AI Chat Interface */}
      <div className="glass-card flex flex-col overflow-hidden h-full">
        <div className="p-4 border-b border-sage-100 flex items-center gap-3 bg-sage-50/50">
          <div className="bg-sage-600 text-white p-2 rounded-xl">
            <Sparkles size={20} />
          </div>
          <div>
            <h3 className="font-bold text-sage-900">Paw-visor Chat</h3>
            <p className="text-[10px] uppercase font-black text-sage-400 tracking-widest">Always verify with a vet</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <AnimatePresence initial={false}>
            {messages.length === 0 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-6"
              >
                <div className="bg-sage-50 p-6 rounded-3xl text-sm text-sage-600 leading-relaxed border border-sage-100">
                  Hi there! I'm your AI wellness companion. I can help you understand <strong>{dog.name}'s</strong> specific needs based on their breed and activity level. Ask me anything about fitness, health tips, or exercise safety!
                </div>
                <div className="grid grid-cols-1 gap-2">
                  <p className="text-[10px] uppercase font-black text-sage-400 tracking-widest ml-1 mb-1">Try asking</p>
                  {suggestedQuestions.map((q, i) => (
                    <button 
                      key={i} 
                      onClick={() => setInput(q.text)}
                      className="text-left p-3 rounded-2xl bg-white border border-sage-100 text-xs font-bold text-sage-700 hover:bg-sage-50 transition-colors flex items-center justify-between group"
                    >
                      {q.text}
                      <ChevronRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
            
            {messages.map((msg, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[85%] p-4 rounded-3xl shadow-sm ${msg.role === 'user' ? 'bg-sage-700 text-white rounded-br-none' : 'bg-cream-200 text-sage-900 rounded-bl-none border border-sage-100'}`}>
                  <div className="prose prose-sm prose-sage max-w-none">
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                  </div>
                </div>
              </motion.div>
            ))}
            
            {isLoading && (
              <motion.div className="flex justify-start">
                <div className="bg-cream-200 p-4 rounded-3xl animate-pulse flex gap-2">
                  <div className="w-2 h-2 bg-sage-400 rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-sage-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <div className="w-2 h-2 bg-sage-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <form onSubmit={handleSend} className="p-4 bg-white border-t border-sage-100 flex gap-2">
          <input 
            value={input}
            onChange={e => setInput(e.target.value)}
            disabled={isLoading}
            placeholder={`Ask about ${dog.name}...`}
            className="flex-1 bg-sage-50 border-none rounded-2xl px-5 py-3 text-sm focus:ring-2 focus:ring-sage-500 outline-none transition-all"
          />
          <button 
            type="submit"
            disabled={isLoading || !input.trim()}
            className="bg-sage-700 text-white p-3 rounded-2xl disabled:opacity-50 hover:bg-sage-800 transition-colors shadow-lg active:scale-95 transition-transform"
          >
            <Send size={20} />
          </button>
        </form>
      </div>

      {/* Routine Generator Side */}
      <div className="space-y-6 h-full overflow-y-auto pr-2 custom-scrollbar">
        <div className="glass-card p-8 bg-gradient-to-br from-cream-200 to-sage-100 border-none relative overflow-hidden">
          <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
            <Sparkles size={120} />
          </div>
          <div className="relative z-10 flex flex-col h-full">
            <div className="mb-6">
              <h3 className="text-2xl font-bold serif text-sage-900 mb-2">AI Daily Routine</h3>
              <p className="text-sage-600 text-sm">Generate a customized fitness schedule perfectly matched for <strong>{dog.name}'s</strong> age and energy levels.</p>
            </div>
            
            {!routine && (
              <button 
                onClick={handleGenerateRoutine}
                disabled={isGeneratingRoutine}
                className="mt-4 bg-sage-700 text-white px-8 py-4 rounded-3xl font-black flex items-center justify-center gap-3 hover:bg-sage-800 transition-all shadow-xl disabled:opacity-50 group"
              >
                {isGeneratingRoutine ? 'Sniffing out ideas...' : <>Generate Schedule <Wand2 size={24} className="group-hover:rotate-12 transition-transform" /></>}
              </button>
            )}

            {routine && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="grid grid-cols-1 gap-4">
                  <RoutineSegment title="Morning" content={routine.morning} />
                  <RoutineSegment title="Afternoon" content={routine.afternoon} />
                  <RoutineSegment title="Evening" content={routine.evening} />
                </div>
                
                <div className="bg-white/50 p-6 rounded-3xl border border-white/50">
                  <h4 className="font-bold text-sage-900 mb-4 flex items-center gap-2">
                    <Sparkles size={18} className="text-cream-500" /> Pro Tips
                  </h4>
                  <ul className="space-y-3">
                    {routine.tips.map((tip: string, i: number) => (
                      <li key={i} className="text-xs font-medium text-sage-600 flex gap-3">
                        <span className="w-1.5 h-1.5 bg-sage-400 rounded-full mt-1.5 flex-shrink-0" />
                        {tip}
                      </li>
                    ))}
                  </ul>
                </div>

                <button 
                  onClick={handleGenerateRoutine}
                  className="w-full text-center text-xs font-bold text-sage-500 uppercase tracking-widest hover:text-sage-800 transition-colors"
                >
                  Regenerate Routine
                </button>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function RoutineSegment({ title, content }: { title: string, content: string }) {
  return (
    <div className="bg-white/80 backdrop-blur-sm p-5 rounded-2xl border border-white/40 shadow-sm">
      <h5 className="text-[10px] uppercase font-black text-sage-400 tracking-widest mb-1">{title}</h5>
      <p className="text-sm font-bold text-sage-800 leading-tight">{content}</p>
    </div>
  );
}
