/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Activity } from '../types';
import { Footprints, Gamepad2, Brain, Coffee, Calendar } from 'lucide-react';
import { formatDate } from '../lib/utils';
import { motion } from 'motion/react';

interface ActivityLogProps {
  activities: Activity[];
}

const ICON_MAP = {
  walk: <Footprints size={18} />,
  play: <Gamepad2 size={18} />,
  training: <Brain size={18} />,
  other: <Coffee size={18} />,
};

const COLOR_MAP = {
  walk: 'bg-sage-100 text-sage-600',
  play: 'bg-cream-200 text-cream-500',
  training: 'bg-orange-100 text-orange-600',
  other: 'bg-slate-100 text-slate-600',
};

export default function ActivityLog({ activities }: ActivityLogProps) {
  if (activities.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-20 text-center text-sage-400">
        <Calendar size={64} strokeWidth={1} className="mb-4 opacity-50" />
        <h3 className="text-xl font-bold serif mb-2">History is Empty</h3>
        <p className="max-w-xs text-sm">Activities will appear here once you start logging your dog's routines.</p>
      </div>
    );
  }

  // Group by day
  const grouped = activities.reduce((acc, curr) => {
    const day = curr.timestamp.split('T')[0];
    if (!acc[day]) acc[day] = [];
    acc[day].push(curr);
    return acc;
  }, {} as Record<string, Activity[]>);

  const sortedDays = Object.keys(grouped).sort((a, b) => b.localeCompare(a));

  return (
    <div className="max-w-3xl mx-auto space-y-10">
      {sortedDays.map((day, idx) => (
        <section key={day} className="relative">
          {idx !== sortedDays.length - 1 && (
            <div className="absolute left-6 top-10 bottom-0 w-0.5 bg-sage-200 hidden md:block" />
          )}
          
          <div className="flex items-center gap-4 mb-6">
            <div className="bg-sage-600 text-white px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest shadow-lg">
              {new Date(day).toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
            </div>
            <div className="flex-1 h-px bg-sage-100" />
          </div>

          <div className="space-y-4 ml-0 md:ml-12">
            {grouped[day].map((activity) => (
              <motion.div 
                key={activity.id}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-card p-4 flex items-center justify-between group hover:border-sage-300 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-2xl ${COLOR_MAP[activity.type]}`}>
                    {ICON_MAP[activity.type]}
                  </div>
                  <div>
                    <h4 className="font-bold text-sage-900 capitalize">{activity.type} Session</h4>
                    <p className="text-xs text-sage-500 font-medium">
                      {formatDate(activity.timestamp).split(',')[1]} 
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-black text-sage-900">{activity.duration}<span className="text-xs font-bold text-sage-400">m</span></div>
                  <div className="text-[10px] uppercase font-bold text-sage-400 tracking-tighter">Duration</div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
