/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI } from "@google/genai";
import { Dog } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getDogAdvice(dog: Dog, question: string) {
  const model = "gemini-3-flash-preview";
  const prompt = `
    You are a professional dog fitness and wellness advisor called "Paw-visor".
    You are helping a dog owner with their dog: ${dog.name}.
    Dog Details:
    - Breed: ${dog.breed}
    - Age: ${dog.age} years
    - Weight: ${dog.weight} kg
    - Activity Level: ${dog.activityLevel}

    User Question: ${question}

    Provide helpful, expert advice specifically tailored for this dog. Keep the tone encouraging, warm, and professional. Use markdown for formatting. 
    If you recommend specific exercises, explain why they are good for ${dog.breed}.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: [{ parts: [{ text: prompt }] }],
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having a bit of trouble connecting to my dog-senses right now. Please try again in a moment!";
  }
}

export async function generateDailyRoutine(dog: Dog) {
  const model = "gemini-3-flash-preview";
  const prompt = `
    You are a professional dog trainer. Create a simple daily fitness routine for ${dog.name}.
    Spec: ${dog.breed}, ${dog.age} years old, ${dog.weight}kg, ${dog.activityLevel} energy.
    
    Return a JSON object with:
    {
      "morning": "...",
      "afternoon": "...",
      "evening": "...",
      "tips": ["...", "...", "..."]
    }
    The routine should be practical and safe for this breed.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json"
      }
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini API Error:", error);
    return null;
  }
}
